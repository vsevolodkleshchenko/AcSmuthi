class Medium:
    def __init__(
            self,
            density: float,
            pressure_velocity: float
    ):
        self.density = density
        self.cp = pressure_velocity

